const socket = new WebSocket('ws://localhost:3000');

socket.onopen = function(event) {
    console.log('Connected to server');
};

socket.onerror = function(error) {
    console.error('WebSocket Error: ', error);
};

socket.onmessage = function(event) {
    try {
        const data = JSON.parse(event.data);
        if (data.type === 'message') {
            const messageDiv = document.createElement('div');
            messageDiv.textContent = `${data.name}: ${data.text}`;
            document.getElementById('messages').appendChild(messageDiv);
        } else if (data.type === 'clientCount') {
            const countDiv = document.getElementById('user-count');
            countDiv.textContent = `Online users: ${data.count}`;
        }
    } catch (error) {
        console.error('Error handling message:', error);
    }
};

socket.onclose = function(event) {
    console.log('Disconnected from server');
};

// this is for the chat room

function joinRoom() {
    const name = "Anonymous";
    console.log("Name:", name); 
    document.getElementById('chat').style.display = 'block';
    if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: 'join', name: name }));
  } else {
      console.error('WebSocket is not open.');
    }
}

// this is where the messaging of users start and also shows the message

function sendMessage() {
    const message = document.getElementById('message-input').value;
    if (!message) return;
    document.getElementById('message-input').value = '';

    const messageData = { type: 'message', text: message };

    if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(messageData));
    } else {
        console.error('WebSocket is not open.');
    }
}

// this is where the fetching of data will start

async function searchPlant() {
    const query = document.getElementById('search-input').value;
    if (!query) {
        alert('Please enter a plant name');
        return;
    }

    const url = `http://localhost:3000/api/plants?q=${query}`;
    const loadingIndicator = document.getElementById('loading');
    const plantInfoSection = document.getElementById('plant-info');

    loadingIndicator.style.display = 'block';
    plantInfoSection.innerHTML = '';

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        loadingIndicator.style.display = 'none';
        console.log('Fetched plant data:', data); // Debugging log
        if (data.data && data.data.length > 0) {
            displayPlantInfo(data.data[0]);
        } else {
            plantInfoSection.innerHTML = '<p>No plant found.</p>';
        }
    } catch (error) {
        loadingIndicator.style.display = 'none';
        plantInfoSection.innerHTML = `<p>Error fetching plant data: ${error.message}</p>`;
    }
}

// this is for the information of the plants to show

function displayPlantInfo(plant) {
    const plantInfoSection = document.getElementById('plant-info');
    plantInfoSection.innerHTML = '';

    const plantName = document.createElement('h2');
    plantName.textContent = plant.common_name || 'No common name available';

    const plantImage = document.createElement('img');
    plantImage.src = plant.image_url || 'default-image-url.jpg'; 
    plantImage.alt = plant.common_name || 'No common name available';
    plantImage.style.maxWidth = '200px'; 
    plantImage.style.borderRadius = '10px';
    plantImage.style.margin = '20px';

    const details = [
        { label: 'Scientific Name', value: plant.scientific_name },
        { label: 'Common Name', value: plant.common_name },
        { label: 'Family', value: plant.family },
        { label: 'Family Common Name', value: plant.family_common_name },
    ];

    plantInfoSection.appendChild(plantName);
    plantInfoSection.appendChild(plantImage);
    details.forEach(detail => {
        if (detail.value) { 
            const p = document.createElement('p');
            p.className = 'plant-detail';
            p.textContent = `${detail.label}: ${detail.value}`;
            plantInfoSection.appendChild(p);
        }
    });
}