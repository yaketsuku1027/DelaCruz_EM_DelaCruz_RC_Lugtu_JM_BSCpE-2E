const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());

let numClients = 0;

wss.on('connection', function connection(ws) {
    numClients++;
    broadcastClientCount();

    ws.on('message', function incoming(message) {
        try {
            const data = JSON.parse(message);
            if (data.type === 'message') {
                wss.clients.forEach(function each(client) {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({ type: 'message', text: data.text, name: "Anonymous" }));
                    }
                });
            }
        } catch (error) {
            console.error('Error parsing message:', error);
        }
    });

    ws.on('close', function close() {
        numClients--;
        broadcastClientCount();
    });
});

// this is where the number of online shows

function broadcastClientCount() {
    wss.clients.forEach(function each(client) {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type: 'clientCount', count: numClients }));
        }
    });
}


// this is where you will get the data from the api

const apiKey = 'GiZRUgL0Lwfv5lphaRwMOBHgg0kKfXTRkjQcnPU09lI';

app.get('/api/plants', async (req, res) => {
    const query = req.query.q;
    const url = `https://trefle.io/api/v1/plants/search?token=${apiKey}&q=${query}`;
    console.log('Fetching URL:', url);
    try {
        const fetch = (await import('node-fetch')).default;
        const response = await fetch(url);
        const data = await response.json();
        console.log('API response data:', JSON.stringify(data, null, 2));
        if (data.data && data.data.length > 0) {
            res.json(data);
        } else {
            res.json({ data: [] });
        }
    } catch (error) {
        console.error('Error fetching plant data:', error);
        res.status(500).json({ error: 'Error fetching plant data' });
    }
});


const PORT = process.env.PORT || 3000;
server.listen(PORT, function listening() {
    console.log(`Server started on port ${PORT}`);
});